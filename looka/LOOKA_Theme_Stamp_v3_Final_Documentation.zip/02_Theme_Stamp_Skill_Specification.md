# LOOKA Theme Stamp Skill v3 技术规范

## Skill Name

looka_theme_stamp_generator

## 作用

将用户图片和GPT生成结果转换成LOOKA主题印章资产。

Skill负责：

-   图片理解结果接收
-   生成任务管理
-   资产标准化
-   Metadata生成
-   Theme Pack创建
-   Asset Library入库

------------------------------------------------------------------------

# Input Schema

{ image_url:"", user_prompt:"", theme_name:"", style:"LOOKA Cute
Sticker", count:24 }

------------------------------------------------------------------------

# Pipeline

## 1. Image Understanding

读取用户图片。

提取：

-   主体
-   颜色
-   风格
-   个性特征

## 2. Theme Blueprint

生成24个印章设计方案。

每个Blueprint包含：

-   name
-   action
-   emotion
-   category
-   tags

## 3. Image Generation

生成：

24张主题印章。

要求：

-   256×256
-   WebP
-   Transparent

## 4. Asset Processing

自动：

-   去背景
-   主体裁剪
-   居中
-   格式转换

## 5. Metadata生成

输出：

theme.json

metadata.json

------------------------------------------------------------------------

# Theme Pack结构

LOOKA_THEME_PACK

├── theme.json

├── metadata.json

└── assets

    ├── 001.webp
    ├── 002.webp
    ...
    └── 024.webp

------------------------------------------------------------------------

# Quality Control

检查：

-   尺寸
-   格式
-   透明背景
-   无文字
-   无水印
-   风格统一
