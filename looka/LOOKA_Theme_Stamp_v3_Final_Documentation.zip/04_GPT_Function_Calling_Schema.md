# LOOKA GPT Function Calling Schema

## Tool Name

generate_theme_stamp

## Description

Generate a personal LOOKA theme stamp package from user image or
description.

## Parameters

{ theme_name:string,

description:string,

image_url:string,

style:string,

count:number }

------------------------------------------------------------------------

# 调用场景

用户：

"帮我把我的狗做成可爱的手帐贴纸"

GPT：

调用：

generate_theme_stamp

------------------------------------------------------------------------

# 不调用场景

普通聊天。

日期查询。

文字帮助。
