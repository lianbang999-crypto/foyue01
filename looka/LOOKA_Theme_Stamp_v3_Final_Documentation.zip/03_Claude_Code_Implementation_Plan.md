# Claude Code 开发执行计划

## 任务目标

请实现LOOKA Theme Stamp系统。

不要只输出方案。

需要完成代码。

------------------------------------------------------------------------

# Phase 1 数据层

建立：

Theme数据库

Asset数据库

Generation Job数据库

模型：

themes

assets

generation_jobs

calendar_stamp_instances

------------------------------------------------------------------------

# Phase 2 API

实现：

POST

/api/theme-stamp/generate

作用：

创建主题生成任务。

------------------------------------------------------------------------

GET

/api/theme-stamp/jobs/{id}

作用：

查询生成状态。

------------------------------------------------------------------------

GET

/api/themes/{theme_id}

作用：

获取主题包。

------------------------------------------------------------------------

POST

/api/assets/stamps

作用：

上传资产。

------------------------------------------------------------------------

# Phase 3 GPT Tool

实现Function Calling：

generate_theme_stamp

参数：

theme_name

description

image_url

count=24

触发：

用户说：

"帮我把这张照片做成手帐贴纸"

------------------------------------------------------------------------

# Phase 4 Frontend

实现：

StickerPicker

ThemePreview

StampGrid

ApplyToCalendar

------------------------------------------------------------------------

# Phase 5 Calendar Integration

保存：

calendar_stamp_instances

字段：

-   asset_id
-   event_id
-   position
-   scale
-   rotation

------------------------------------------------------------------------

# 最终验收

用户：

上传一张猫照片

系统：

自动生成猫咪主题24枚印章

用户：

点击应用

结果：

印章出现在日历和手帐中。
